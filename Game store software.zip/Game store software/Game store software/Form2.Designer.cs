﻿namespace Game_store_software
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabEmp = new System.Windows.Forms.TabControl();
            this.tabEmployee = new System.Windows.Forms.TabPage();
            this.tabManager = new System.Windows.Forms.TabPage();
            this.TabEmp.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabEmp
            // 
            this.TabEmp.Controls.Add(this.tabEmployee);
            this.TabEmp.Controls.Add(this.tabManager);
            this.TabEmp.Location = new System.Drawing.Point(13, 13);
            this.TabEmp.Name = "TabEmp";
            this.TabEmp.SelectedIndex = 0;
            this.TabEmp.Size = new System.Drawing.Size(775, 425);
            this.TabEmp.TabIndex = 0;
            // 
            // tabEmployee
            // 
            this.tabEmployee.Location = new System.Drawing.Point(4, 22);
            this.tabEmployee.Name = "tabEmployee";
            this.tabEmployee.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmployee.Size = new System.Drawing.Size(767, 399);
            this.tabEmployee.TabIndex = 0;
            this.tabEmployee.Text = "Employee";
            this.tabEmployee.UseVisualStyleBackColor = true;
            this.tabEmployee.Click += new System.EventHandler(this.tabEmployee_Click);
            // 
            // tabManager
            // 
            this.tabManager.Location = new System.Drawing.Point(4, 22);
            this.tabManager.Name = "tabManager";
            this.tabManager.Padding = new System.Windows.Forms.Padding(3);
            this.tabManager.Size = new System.Drawing.Size(767, 399);
            this.tabManager.TabIndex = 1;
            this.tabManager.Text = "Manager";
            this.tabManager.UseVisualStyleBackColor = true;
            this.tabManager.Click += new System.EventHandler(this.tabManager_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TabEmp);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.TabEmp.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabEmp;
        private System.Windows.Forms.TabPage tabEmployee;
        private System.Windows.Forms.TabPage tabManager;
    }
}