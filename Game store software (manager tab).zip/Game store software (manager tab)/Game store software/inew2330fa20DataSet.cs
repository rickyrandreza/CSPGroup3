﻿namespace Game_store_software
{


    partial class inew2330fa20DataSet
    {
    }
}

namespace Game_store_software.inew2330fa20DataSetTableAdapters {
    
    
    public partial class ProductsTableAdapter {
    }
}
