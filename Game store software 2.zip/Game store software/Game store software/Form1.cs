﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game_store_software
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string Manager = "manager";
            string Employee = "employee";
            string EmpPass = "EMPLOYEE";
            string ManPass = "MANAGER";

            if (txtUser.Text == Manager && txtPass.Text == ManPass)
            {
                frmMain form2 = new frmMain();
                form2.EmployeeType = "Manager";
                form2.Show();

            }
            else if (txtUser.Text == Employee && txtPass.Text == EmpPass)
            {
                frmMain form2 = new frmMain();
                form2.EmployeeType = "Employee";
                form2.Show();
            }
            else
            {
                lblError.Text = "Wrong Password or username";
            }
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            btnLogin.Enabled = true;
        }

        private void lblError_Click(object sender, EventArgs e)
        {

        }
    }
}
