﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game_store_software
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        public string EmployeeType;
        private void Form2_Load(object sender, EventArgs e)
        {
            if (EmployeeType == "Employee")
            {
                
            }
        }

        private void tabEmployee_Click(object sender, EventArgs e)
        {

        }

        private void tabManager_Click(object sender, EventArgs e)
        {

        }
    }
}
