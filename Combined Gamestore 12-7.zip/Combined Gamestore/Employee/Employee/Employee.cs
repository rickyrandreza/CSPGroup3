﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeNamespace
{
    public class Employee
    {
        //Fields
        private int empID;
        private string lastname;
        private string firstname;
        private string username;
        private string password;
        private string title;


        public  Employee() //default constructor when you don't set any values
        {

        }
        //Overload constructor with 4 parameters
        public Employee(int empID, string lastname, string firstname,string username, string password, string title)
        {
            EmpID = empID;
            LastName = lastname;
            FirstName = firstname;
            Username = username;
            Password = password;
            Title = title;
        }

        //5 properties to set and to get values for fields 
        public int EmpID
        {
            set
            {
                empID = value;
            }
            get
            {
                return empID;
            }
        }

        public string LastName
        {
            set
            {
                lastname = value;
            }
            get
            {
                return lastname;
            }
        }
        public string FirstName
        {
            set
            {
                firstname = value;
            }
            get
            {
                return firstname;
            }
        }

        public string Username
        {
            set
            {
                username = value;
            }
            get
            {
                return username;
            }
        }

        public string Password
        {
            set
            {
                password = value;
            }
            get
            {
                return password;
            }
        }

        public string Title
        {
            set
            {
                title = value;
            }
            get
            {
                return title;
            }
        }
    }
}
