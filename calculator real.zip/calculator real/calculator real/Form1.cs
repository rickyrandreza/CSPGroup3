﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator_real
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string Operator;
        string num1;
        string num2;
        double numb1;
        double numb2;
        double solution;
        private void btn1_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "1";
        }
        class IfZeroException:Exception
            {
            public static string message = "Divison by 0 is illegal";
            }
            
        private void lblDisplay_Click(object sender, EventArgs e)
        {
           
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "3";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "";
            lblEq.Text = "";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + "0";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = lblDisplay.Text + ".";
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            lblEq.Text = "";
            num1 = lblDisplay.Text;
            lblEq.Text = lblEq.Text + num1;
            Operator = "/";
            lblEq.Text = lblEq.Text + " / ";
            lblDisplay.Text = "";
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            num2 = lblDisplay.Text;
            if (Operator == "/")
            {
                Double.TryParse(num1, out numb1);
                Double.TryParse(num2, out numb2);
                try
                {
                    if (num2 == "0")
                    {
                        throw new IfZeroException();
                    }
                    else
                    {
                        solution = numb1 / numb2;
                        lblEq.Text = solution.ToString();
                        lblDisplay.Text = "";
                    }
                }
                catch
                {
                    MessageBox.Show(IfZeroException.message);
                    lblEq.Text = "";
                    lblDisplay.Text = "";
                }
            }
            else if (Operator == "*")
            {
                Double.TryParse(num1, out numb1);
                Double.TryParse(num2, out numb2);

                solution = numb1 * numb2;
                lblEq.Text = solution.ToString();
                lblDisplay.Text = "";
            }
            else if (Operator == "+")
            {
                Double.TryParse(num1, out numb1);
                Double.TryParse(num2, out numb2);

                solution = numb1 + numb2;
                lblEq.Text = solution.ToString();
                lblDisplay.Text = "";
            }
            else if (Operator == "-")
            {
                Double.TryParse(num1, out numb1);
                Double.TryParse(num2, out numb2);

                solution = numb1 - numb2;
                lblEq.Text = solution.ToString();
                lblDisplay.Text = "";
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            lblEq.Text = "";
            num1 = lblDisplay.Text;
            lblEq.Text = lblEq.Text + num1;
            Operator = "*";
            lblEq.Text = lblEq.Text + " * ";
            lblDisplay.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lblEq.Text = "";
            num1 = lblDisplay.Text;
            lblEq.Text = lblEq.Text + num1;
            Operator = "+";
            lblEq.Text = lblEq.Text + " + ";
            lblDisplay.Text = "";
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            lblEq.Text = "";
            num1 = lblDisplay.Text;
            lblEq.Text = lblEq.Text + num1;
            Operator = "-";
            lblEq.Text = lblEq.Text + " - ";
            lblDisplay.Text = "";
        }
    }
}
