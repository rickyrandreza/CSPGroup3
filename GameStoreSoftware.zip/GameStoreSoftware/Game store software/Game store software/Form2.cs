﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using ProductNamespace;//Class Product 




namespace Game_store_software
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        //Close App
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Class used to link and manage external data
        SqlConnection Connection = new SqlConnection("Server = cstnt.tstc.edu;" 
          + "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
         SqlCommand Cmd;
         SqlDataAdapter dataAd;
         DataTable dt;
         Product product;

        //Variable for calculation
        double totalPrice;
        int qtyReq;

        
        //Method to display table product
        public void showData()
        {
            try
            {
                Connection.Open();
                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataGridViewProduct.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        //Display DataGridViewProduct for cashier use only
        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            showData();
            //Build datagriedviewCart to add up order in cart
            dataGridViewList.ColumnCount = 3;
            dataGridViewList.Columns[0].Name = "Product";
            dataGridViewList.Columns[1].Name = "Qty";
            dataGridViewList.Columns[2].Name = "Price";
        }

        //Method to pass value in DatagridViewList
        private void addCart(string Name, string Qty, string Price)
        {
            string[] row = { Name, Qty, Price };
            dataGridViewList.Rows.Add(row);
        }

        //Method for calculate  quantity total price
        private double QuantityPrice(double priceProduct, int qtyProd)
        {
            double Total;
            Total = priceProduct * qtyProd;
            return Total;
        }

        //Add selected product in the datagridViewList
        private void btnAddCart_Click(object sender, EventArgs e)
        {
            if (tbxQty.Text != "" && lblQtyAv.Text != "" && lblPrice.Text != "")//Make sure to enter input
            {
                //ACCEPT INPUT FROM USER 
                qtyReq = int.Parse(tbxQty.Text);

                if (qtyReq > 0 && qtyReq < int.MaxValue)//range of number accepted 
                {
                    //Check if quantity is available
                    if (qtyReq < product.Quantity)
                    {
                        //Display selection in the cart and increment total                   
                        totalPrice = QuantityPrice(product.Price, qtyReq);
                        string strtotalPrice = totalPrice.ToString();
                        addCart(product.Name, tbxQty.Text, strtotalPrice);
                    }
                    else//if quantity out of stock
                    {
                        MessageBox.Show("Quantity Unavailable", "Message");
                        tbxQty.Focus();
                        tbxQty.Clear();
                    }

                }
                else //if quantity negatif number
                {
                    MessageBox.Show(" Invalid quantity number", "Message");
                    tbxQty.Focus();
                    tbxQty.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please, Select Product or Enter Quantity ", "Message");
                tbxQty.Focus();
                tbxQty.Clear();

            }
        
               
            lblQtyAv.Text = "";
            lblProduct.Text = "";
            lblConsole.Text = "";
            tbxQty.Text = "";
            lblPrice.Text = "";
            tbxQty.Focus();
        }

        //Display grid selection in the labels
        private void dataGridViewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tbxQty.Focus();

            try
            {
                
                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.dataGridViewProduct.Rows[e.RowIndex];                   
                    product = new Product();
                    product.Name = row.Cells["Description"].Value.ToString();
                    product.Quantity = int.Parse(row.Cells["Quantity"].Value.ToString());
                    product.Price = Convert.ToDouble(row.Cells["Retail"].Value.ToString());                   
                    product.Category = row.Cells["Category"].Value.ToString();
                    product.Console = row.Cells["Console"].Value.ToString();

                    lblQtyAv.Text = Convert.ToString(product.Quantity);
                    lblPrice.Text = Convert.ToString(product.Price);
                    lblProduct.Text= Convert.ToString(product.Name);
                    lblConsole.Text = Convert.ToString(product.Console);
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }

        }

        public string EmployeeType;
        private void Form2_Load(object sender, EventArgs e)
        {
            if (EmployeeType == "Employee")
            {

            }
        }

        private void tabEmployee_Click(object sender, EventArgs e)
        {

        }

        private void tabManager_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

       
    }
}
