﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//Database connection

namespace Game_store_software
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        SqlConnection cntDatabase;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;

            //connect to database
            cntDatabase = new SqlConnection("Server=cstnt.tstc.edu;" +
                "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
            //open the database
            cntDatabase.Open();
            //display message
            lblMessage.Text = cntDatabase.State.ToString();
            //close the database
            cntDatabase.Close();
            lblMessage.Text += cntDatabase.State.ToString();
            //dispose of the connection object
            cntDatabase.Dispose();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            string Manager = "manager";
            string Employee = "employee";
            string EmpPass = "EMPLOYEE";
            string ManPass = "MANAGER";

            if (txtUser.Text == Manager && txtPass.Text == ManPass)
            {
                frmMain form2 = new frmMain();
                form2.EmployeeType = "Manager";
                form2.Show();

            }
            else if (txtUser.Text == Employee && txtPass.Text == EmpPass)
            {
                frmMain form2 = new frmMain();
                form2.EmployeeType = "Employee";
                form2.Show();
            }
            else
            {
                lblMessage.Text = "Wrong Password or username";
            }
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {
            btnLogin.Enabled = true;
        }

        private void lblError_Click(object sender, EventArgs e)
        {

        }
    }
}
