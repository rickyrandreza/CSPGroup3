﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Game_store_software;
using LoginValidationNamespace;


using ProductNamespace;//Class Product 




namespace Game_store_software
{
    public partial class CashierFormMain : Form
    {
        private LoginValidation attempt;

        public CashierFormMain()
        {
            InitializeComponent();

            labael2.Enabled = false;
            label2.Enabled = false;
            label5.Enabled = false;
            label9.Enabled = false;
            label12.Enabled = false;
            label11.Enabled = false;
            label3.Enabled = false;
            lblDate.Text = DateTime.Now.ToShortDateString();//Get date
            lblTime.Text = DateTime.Now.ToShortTimeString();//Get time
            //lblClerkName.Text = attempt.Username.ToString();
            dataGridViewList.Visible = false;
            dataGridViewProduct.Visible = false;
            label12.Enabled = false;
            label11.Enabled = false;
            btnAddCart.Enabled = false;
            gpBxPayment.Enabled = false;
            label10.Enabled = false;
            label8.Enabled = false;
            label7.Enabled = false;
            label13.Enabled = false;
            label15.Enabled = false;
            tbxQty.Enabled = false;

        }

        
        //Close App
        private void buttonExit_Click(object sender, EventArgs e)
        {
            //Message and Action when transaction made
            DialogResult result = MessageBox.Show("Do you want to Exit Program", "Confirmation", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                Application.Exit();
            }
          


        }

        //Class used to link and manage external data
        SqlConnection Connection = new SqlConnection("Server = cstnt.tstc.edu;" 
          + "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
         SqlCommand Cmd;
         SqlDataAdapter dataAd;
         DataTable dt;
         Product product;

        //Variable for calculation
        double totalPrice=0;
        int qtyReq=0;
        int qtyUpdate = 0;

        double cashReceived = 0;
        double cashreturned = 0;


        //Method to display table product
        public void showData()
        {
            try
            {
                Connection.Open();
                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataGridViewProduct.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        //Display DataGridViewProduct for cashier use only
        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            dataGridViewList.Visible = true;
            dataGridViewProduct.Visible = true;
            btnAddCart.Enabled = true;
            btnAddCart.Enabled = true;
            lblQtyAv.Enabled = true;
            lblSelectProd.Visible = true;
            showData();
            //Build datagriedviewCart to add up order in cart
            dataGridViewList.ColumnCount = 3;
            dataGridViewList.Columns[0].Name = "Product";
            dataGridViewList.Columns[1].Name = "Qty";
            dataGridViewList.Columns[2].Name = "Price";
        }

        //Method to pass value in DatagridViewList
        private void addCart(string Name, string Qty, string Price)
        {
            string[] row = { Name, Qty, Price };
            dataGridViewList.Rows.Add(row);
        }

        //Method for calculate  quantity total price
        private double QuantityPrice(double priceProduct, int qtyProd)
        {
            double Total;
            Total = priceProduct * qtyProd;
            return Total;
        }

        //method to calculate and display amounts without discount
        private double calculateAndDisplayNoDiscount(double rateDiscount=0)
        {
            double totalList = 0;
            double tax = 0.0625;
            double AmountTotal = 0;
            double amountTax = 0;
            double totalWithDiscount=0;
            double discountValue;
            if (dataGridViewList.Rows.Count > 1)//make sure datalist is not empty
            {

                //cumulate Total Price of order from list cart
                for (int i = 0; i < dataGridViewList.Rows.Count - 1; i++)
                {
                    totalList = totalList + Convert.ToDouble(dataGridViewList.Rows[i].Cells[2].Value.ToString());
                }


                //Calculate and display               
                discountValue = totalList * rateDiscount;
                double priceWithDiscount = totalList - discountValue;
                amountTax = priceWithDiscount*tax;
                AmountTotal = priceWithDiscount+amountTax;
                totalWithDiscount = AmountTotal;
                lblDiscount.Text = discountValue.ToString("N2");
                lblAmtTotal.Text = totalList.ToString("N2");
                lblTotalToPay.Text = AmountTotal.ToString("N2");
                lblTax.Text = amountTax.ToString("N2");
               
            }
           
            return totalWithDiscount;
        }
    

        //Add selected product in the datagridViewList
        private void btnAddCart_Click(object sender, EventArgs e)
        {

            if (tbxQty.Text!="")//make sure quantity selection is filled before to enable function
            {
                dataGridViewList.Enabled = false;//Disable auto select in datagridview
                btnCheckout.Enabled = true;
                rdBDiscount15.Enabled = true;
                rdBDiscountNone.Enabled = true;
                rdBDiscount30.Enabled = true;
                gpBxPayment.Enabled = true;
                label12.Enabled = true;
                label10.Enabled = true;
                label8.Enabled = true;
                label7.Enabled = true;
                label13.Enabled = true;
                label15.Enabled = true;
            }
         
            try
            {
                if (tbxQty.Text != "" && lblQtyAv.Text != "" && lblPrice.Text != "")//Make sure to enter input
                {
                    //ACCEPT INPUT FROM USER 
                    qtyReq = int.Parse(tbxQty.Text);

                    if (qtyReq > 0 && qtyReq < int.MaxValue)//range of number accepted 
                    {
                        //Check if quantity is available
                        if (qtyReq < product.Quantity)
                        {
                            //Display selection in the cart and increment total                   
                            totalPrice = QuantityPrice(product.Price, qtyReq);
                            string strtotalPrice = totalPrice.ToString();
                            addCart(product.Name, tbxQty.Text, strtotalPrice);

                            //substract qty available to qty req to update qty in the dataGridProduct                  
                            qtyUpdate = product.Quantity - qtyReq;
                            //grab current row index selected          
                            int x = dataGridViewProduct.CurrentCell.RowIndex;
                            //Insert quantity updated to current row and Cell "Quantity" index 2
                            dataGridViewProduct.Rows[x].Cells[2].Value = Convert.ToString(qtyUpdate);
                        }
                        else//if quantity out of stock
                        {
                            MessageBox.Show("Quantity Unavailable", "Message");
                            tbxQty.Focus();
                            tbxQty.Clear();
                        }

                    }
                    else //if quantity negatif number
                    {
                        MessageBox.Show(" Invalid quantity number", "Message");
                        tbxQty.Focus();
                        tbxQty.Clear();
                    }

                    //Call method calculate and display with no discount
                    calculateAndDisplayNoDiscount();
                }
                else
                {
                    MessageBox.Show("Select Product or Enter Quantity ", "Message");
                    tbxQty.Focus();
                    tbxQty.Clear();

                }

            }
            catch (FormatException)
            {
                MessageBox.Show(" Numeric Input ", "Message");
                tbxQty.Text = "";
                tbxQty.Focus();
                lblConsole.Text = "";
                lblProduct.Text = "";
                lblQtyAv.Text = "";
                lblPrice.Text = "";
            }

            

        }
   
        //Display grid selection in the labels
        private void dataGridViewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tbxQty.Focus();
            labael2.Enabled = true;
            label2.Enabled = true;
            label5.Enabled = true;
            label9.Enabled = true;
            label3.Enabled = true;
            tbxQty.Enabled = true;
            try
            {
                
                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.dataGridViewProduct.Rows[e.RowIndex];                   
                    product = new Product();
                    product.Name = row.Cells["Description"].Value.ToString();
                    product.Quantity = int.Parse(row.Cells["Quantity"].Value.ToString());
                    product.Price = Convert.ToDouble(row.Cells["Retail"].Value.ToString());                   
                    product.Category = row.Cells["Category"].Value.ToString();
                    product.Console = row.Cells["Console"].Value.ToString();
                    

                    lblQtyAv.Text = Convert.ToString(product.Quantity);
                    lblPrice.Text = Convert.ToString(product.Price);
                    lblProduct.Text= Convert.ToString(product.Name);
                    lblConsole.Text = Convert.ToString(product.Console);
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }

        }

        public string EmployeeType;
        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'inew2330fa20DataSet1.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.inew2330fa20DataSet1.Employees);
            // TODO: This line of code loads data into the 'inew2330fa20DataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.inew2330fa20DataSet.Products);
            if (EmployeeType == "Employee")
            {

            }
        }


        //CHECKOUT
        private void btnCheckout_Click(object sender, EventArgs e)
        {


            if (rdBtnCash.Checked == true || rdBtnCredit.Checked == true)//make sure to choose payment method

            {
                //if Cash checked
                if (rdBtnCash.Checked == true)//display cash received and returned                                 
                {
                    label11.Enabled = true;
                    label14.Enabled = true;
                    tbxCash.Enabled = true;
                    tbxCash.Focus();
                    lblReturn.Enabled = true;
                    
                    if (tbxCash.Text != "")//make sure to enter cash
                    {
                        cashReceived = double.Parse(tbxCash.Text);
                        double AmountTotal = double.Parse(lblTotalToPay.Text);

                        cashreturned = cashReceived - AmountTotal;
                        lblReturn.Text = cashreturned.ToString("N2");
                  
                        MessageBox.Show("Total is "+ AmountTotal.ToString("N2")+
                            "\nChange is "+ cashreturned.ToString("N2"), "Message");
                        reset();

                    }
                    else
                    {
                        MessageBox.Show("Please, enter Cash Value", "Message");
                        tbxCash.Focus();
                        cashReceived = 0;
                    }

                }
                else//if credit card checked
                {
                    MessageBox.Show("Please Insert card", "Credit Card");
                    MessageBox.Show("Successful transaction", "Message");
                    reset();
                 
                }
            }
            else
            {
                MessageBox.Show("Please choose payment method", "Payment Method");
            }
            
        }

        //Activate cash payement features
        private void rdBtnCash_CheckedChanged(object sender, EventArgs e)
        {
            label11.Enabled = true;
            label14.Enabled = true;
            tbxCash.Enabled = true;
            tbxCash.Focus();
            lblReturn.Enabled = true;            
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        public void reset()//Method for reset
        {
            //reset if start new order
            dataGridViewList.Rows.Clear();
            //AmountTotal = 0;
            //PriceTax = 0;
            //discount = 0;
            btnCheckout.Enabled = false;
            gpBxPayment.Enabled = false;
            rdBDiscount15.Enabled = false;
            rdBDiscountNone.Enabled = false;
            rdBDiscount30.Enabled = false;
            cashreturned = 0;
            cashReceived = 0;
            totalPrice = 0;
            lblAmtTotal.Text = "";
            lblDiscount.Text = "";
            lblReturn.Text = "";
            lblTax.Text = "";
            tbxCash.Text = "";
            lblTotalToPay.Text = "";
            dataGridViewList.Visible = false;
            dataGridViewProduct.Visible = false;
            dataGridViewProduct.Enabled = true;
            rdBtnCash.Checked = false;
            rdBtnCredit.Checked = false;
            tbxCash.Enabled = false;
            lblReturn.Enabled = false;
            btnAddCart.Enabled = false;
            lblQtyAv.Enabled = false;
            lblQtyAv.Text = "";
            lblPrice.Text = "";
            lblProduct.Text = "";
            lblConsole.Text = "";
            tbxQty.Clear();
            labael2.Enabled = false;
            label2.Enabled = false;
            label5.Enabled = false;
            label9.Enabled = false;
            label3.Enabled = false;
            label12.Enabled = false;
            label11.Enabled = false;
            label10.Enabled = false;
            label8.Enabled = false;
            label7.Enabled = false;
            label13.Enabled = false;
            label15.Enabled = false;
            tbxQty.Enabled = false;
        }
        //Apply Discount 
        private void rdBDiscountNone_CheckedChanged(object sender, EventArgs e)
        {
            calculateAndDisplayNoDiscount();
        }

        private void rdBDiscount15_CheckedChanged(object sender, EventArgs e)
        {
            double discRate = 0.15;
            calculateAndDisplayNoDiscount(discRate);
        }

        private void rdBDiscount30_CheckedChanged(object sender, EventArgs e)
        {
            double discRate = 0.30;
            calculateAndDisplayNoDiscount(discRate);
        }

        //Logout
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();            
            reset();
            frmLogin FormMain = new frmLogin();
            FormMain.Show();
            
        }

        private void tabEmployee_Click(object sender, EventArgs e)
        {

        }

        private void tabManager_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void manage_Click(object sender, EventArgs e)
        {
            dataView.ClearSelection(); //Disable auto select in datagridview

            btnAddCart.Enabled = true;
            lblSelectProd.Visible = true;
            showData2();
            //Build datagriedviewCart to add up order in cart
        }
        public void showData2()
        {
            try
            {
                Connection.Open();
                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void plus1_Click(object sender, EventArgs e)
        {
            product.Quantity += 1;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void plus_Click(object sender, EventArgs e)
        {
            product.Quantity += 5;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void plus10_Click(object sender, EventArgs e)
        {
            product.Quantity += 10;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void minus1_Click(object sender, EventArgs e)
        {
            product.Quantity -= 1;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void minus5_Click(object sender, EventArgs e)
        {
            product.Quantity -= 5;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void minus10_Click(object sender, EventArgs e)
        {
            product.Quantity -= 10;
            try
            {
                Connection.Open();
                this.productsTableAdapter.UpdateQuantity(product.Quantity, product.Name);

                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataView.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void dataView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tbxQty.Focus();

            try
            {

                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.dataView.Rows[e.RowIndex];
                    product = new Product();
                    product.Name = row.Cells["Description"].Value.ToString();
                    product.Quantity = int.Parse(row.Cells["Quantity"].Value.ToString());
                    product.Price = Convert.ToDouble(row.Cells["Retail"].Value.ToString());
                    product.Category = row.Cells["Category"].Value.ToString();
                    product.Console = row.Cells["Console"].Value.ToString();



                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void AddNewItemBtn_Click(object sender, EventArgs e)
        {
            int newQuantity = Convert.ToInt32(txtNewQuantity.Text);
            decimal newCost = Convert.ToDecimal(txtNewCost.Text);

            this.productsTableAdapter.InsertNewItem(txtNewDiscription.Text, txtNewConsole.Text, newQuantity, txtNewCategory.Text, newCost, newCost);
            dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
            dt = new DataTable();
            dataAd.Fill(dt);
            dataView.DataSource = dt;
            Connection.Close();
            txtNewDiscription.Text = "";
            txtNewConsole.Text = "";
            txtNewQuantity.Text = "";
            txtNewCategory.Text = "";
            txtNewCost.Text = "";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Connection.Open();
           EmpData.DataSource = this.employeesTableAdapter.GetData();
            Connection.Close();
        }

        private void EmpData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.EmpData.Rows[e.RowIndex];
                    int empID = int.Parse(row.Cells["EmplID"].Value.ToString());
                   

                    txtEmpID.Text = empID.ToString(); 
                    




                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.employeesTableAdapter.InsertNewEmp(txtLast.Text, txtFirst.Text, txtTitle.Text, txtBirth.Text, txtHire.Text, txtUser.Text, txtPass.Text, txtPhone.Text, txtAddress.Text, txtCity.Text, txtState.Text, txtZip.Text);
            Connection.Open();
            EmpData.DataSource = this.employeesTableAdapter.GetData();
            Connection.Close();
            txtEmpID.Text = "";
            txtLast.Text = "";
            txtFirst.Text = "";
            txtTitle.Text = "";
            txtBirth.Text = "";
            txtHire.Text = "";
            txtUser.Text = "";
            txtPass.Text = "";
            txtPhone.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtZip.Text = "";
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int empID = int.Parse(txtEmpID.Text);
            this.employeesTableAdapter.DeleteEmp(empID);
            Connection.Open();
            EmpData.DataSource = this.employeesTableAdapter.GetData();
            Connection.Close();
            txtEmpID.Text = "";
        }
    }
}
