﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_store_software
{
    class LoginFailException : Exception
    {
        private static string msg = "Login failed. Try again.";

        public LoginFailException() : base(msg)
        { 

            //this exception is going to be thrown by the login form code if the user fails to log in.
        }
    }
}
