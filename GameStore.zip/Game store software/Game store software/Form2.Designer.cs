﻿namespace Game_store_software
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.TabEmp = new System.Windows.Forms.TabControl();
            this.tabPOS = new System.Windows.Forms.TabPage();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnAddCart = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSelectProd = new System.Windows.Forms.Label();
            this.cbxDiscount = new System.Windows.Forms.CheckBox();
            this.gpBxDiscount = new System.Windows.Forms.GroupBox();
            this.rdBtn50 = new System.Windows.Forms.RadioButton();
            this.rdBtn30 = new System.Windows.Forms.RadioButton();
            this.rdBtn15 = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.gpBxPayment = new System.Windows.Forms.GroupBox();
            this.tbxCash = new System.Windows.Forms.TextBox();
            this.rdBtnCredit = new System.Windows.Forms.RadioButton();
            this.rdBtnCash = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.lblReturn = new System.Windows.Forms.Label();
            this.lblTotalToPay = new System.Windows.Forms.Label();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblAmtTotal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxQty = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblConsole = new System.Windows.Forms.Label();
            this.lblQtyAv = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labael2 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.dataGridViewProduct = new System.Windows.Forms.DataGridView();
            this.lblClerkName = new System.Windows.Forms.Label();
            this.dataGridViewList = new System.Windows.Forms.DataGridView();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabManager = new System.Windows.Forms.TabPage();
            this.lblDbState = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.TabEmp.SuspendLayout();
            this.tabPOS.SuspendLayout();
            this.gpBxDiscount.SuspendLayout();
            this.gpBxPayment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewList)).BeginInit();
            this.SuspendLayout();
            // 
            // TabEmp
            // 
            this.TabEmp.Controls.Add(this.tabPOS);
            this.TabEmp.Controls.Add(this.tabManager);
            this.TabEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabEmp.Location = new System.Drawing.Point(-3, 5);
            this.TabEmp.Name = "TabEmp";
            this.TabEmp.SelectedIndex = 0;
            this.TabEmp.Size = new System.Drawing.Size(789, 499);
            this.TabEmp.TabIndex = 0;
            // 
            // tabPOS
            // 
            this.tabPOS.BackColor = System.Drawing.Color.Transparent;
            this.tabPOS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPOS.BackgroundImage")));
            this.tabPOS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tabPOS.Controls.Add(this.label13);
            this.tabPOS.Controls.Add(this.btnReset);
            this.tabPOS.Controls.Add(this.btnAddCart);
            this.tabPOS.Controls.Add(this.label4);
            this.tabPOS.Controls.Add(this.lblSelectProd);
            this.tabPOS.Controls.Add(this.cbxDiscount);
            this.tabPOS.Controls.Add(this.gpBxDiscount);
            this.tabPOS.Controls.Add(this.label11);
            this.tabPOS.Controls.Add(this.gpBxPayment);
            this.tabPOS.Controls.Add(this.lblReturn);
            this.tabPOS.Controls.Add(this.lblTotalToPay);
            this.tabPOS.Controls.Add(this.lblDiscount);
            this.tabPOS.Controls.Add(this.label7);
            this.tabPOS.Controls.Add(this.label12);
            this.tabPOS.Controls.Add(this.lblAmtTotal);
            this.tabPOS.Controls.Add(this.label10);
            this.tabPOS.Controls.Add(this.lblTax);
            this.tabPOS.Controls.Add(this.label8);
            this.tabPOS.Controls.Add(this.tbxQty);
            this.tabPOS.Controls.Add(this.lblPrice);
            this.tabPOS.Controls.Add(this.lblConsole);
            this.tabPOS.Controls.Add(this.lblQtyAv);
            this.tabPOS.Controls.Add(this.lblProduct);
            this.tabPOS.Controls.Add(this.label3);
            this.tabPOS.Controls.Add(this.label2);
            this.tabPOS.Controls.Add(this.label9);
            this.tabPOS.Controls.Add(this.label5);
            this.tabPOS.Controls.Add(this.label6);
            this.tabPOS.Controls.Add(this.labael2);
            this.tabPOS.Controls.Add(this.lblTime);
            this.tabPOS.Controls.Add(this.lblDate);
            this.tabPOS.Controls.Add(this.dataGridViewProduct);
            this.tabPOS.Controls.Add(this.lblClerkName);
            this.tabPOS.Controls.Add(this.dataGridViewList);
            this.tabPOS.Controls.Add(this.btnLogout);
            this.tabPOS.Controls.Add(this.btnCheckout);
            this.tabPOS.Controls.Add(this.btnNewOrder);
            this.tabPOS.Controls.Add(this.label1);
            this.tabPOS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPOS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPOS.Location = new System.Drawing.Point(4, 25);
            this.tabPOS.Name = "tabPOS";
            this.tabPOS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPOS.Size = new System.Drawing.Size(781, 470);
            this.tabPOS.TabIndex = 0;
            this.tabPOS.Text = "POS System";
            this.tabPOS.Click += new System.EventHandler(this.tabEmployee_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReset.BackgroundImage")));
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReset.Location = new System.Drawing.Point(513, 425);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 20;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnAddCart
            // 
            this.btnAddCart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddCart.BackgroundImage")));
            this.btnAddCart.Enabled = false;
            this.btnAddCart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddCart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCart.Location = new System.Drawing.Point(224, 258);
            this.btnAddCart.Name = "btnAddCart";
            this.btnAddCart.Size = new System.Drawing.Size(97, 27);
            this.btnAddCart.TabIndex = 1;
            this.btnAddCart.Text = "Add Cart";
            this.btnAddCart.UseVisualStyleBackColor = true;
            this.btnAddCart.Click += new System.EventHandler(this.btnAddCart_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "Order List:";
            // 
            // lblSelectProd
            // 
            this.lblSelectProd.AutoSize = true;
            this.lblSelectProd.Location = new System.Drawing.Point(11, 48);
            this.lblSelectProd.Name = "lblSelectProd";
            this.lblSelectProd.Size = new System.Drawing.Size(127, 16);
            this.lblSelectProd.TabIndex = 19;
            this.lblSelectProd.Text = "Select your Product:";
            // 
            // cbxDiscount
            // 
            this.cbxDiscount.AutoSize = true;
            this.cbxDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDiscount.Location = new System.Drawing.Point(410, 309);
            this.cbxDiscount.Name = "cbxDiscount";
            this.cbxDiscount.Size = new System.Drawing.Size(79, 20);
            this.cbxDiscount.TabIndex = 16;
            this.cbxDiscount.Text = "Discount";
            this.cbxDiscount.UseVisualStyleBackColor = true;
            this.cbxDiscount.CheckedChanged += new System.EventHandler(this.cbxDiscount_CheckedChanged);
            // 
            // gpBxDiscount
            // 
            this.gpBxDiscount.Controls.Add(this.rdBtn50);
            this.gpBxDiscount.Controls.Add(this.rdBtn30);
            this.gpBxDiscount.Controls.Add(this.rdBtn15);
            this.gpBxDiscount.Enabled = false;
            this.gpBxDiscount.Location = new System.Drawing.Point(412, 328);
            this.gpBxDiscount.Name = "gpBxDiscount";
            this.gpBxDiscount.Size = new System.Drawing.Size(77, 75);
            this.gpBxDiscount.TabIndex = 18;
            this.gpBxDiscount.TabStop = false;
            // 
            // rdBtn50
            // 
            this.rdBtn50.AutoSize = true;
            this.rdBtn50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBtn50.Location = new System.Drawing.Point(14, 52);
            this.rdBtn50.Name = "rdBtn50";
            this.rdBtn50.Size = new System.Drawing.Size(52, 20);
            this.rdBtn50.TabIndex = 14;
            this.rdBtn50.TabStop = true;
            this.rdBtn50.Text = "50%";
            this.rdBtn50.UseVisualStyleBackColor = true;
            this.rdBtn50.CheckedChanged += new System.EventHandler(this.rdBtn50_CheckedChanged);
            // 
            // rdBtn30
            // 
            this.rdBtn30.AutoSize = true;
            this.rdBtn30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBtn30.Location = new System.Drawing.Point(14, 30);
            this.rdBtn30.Name = "rdBtn30";
            this.rdBtn30.Size = new System.Drawing.Size(52, 20);
            this.rdBtn30.TabIndex = 14;
            this.rdBtn30.TabStop = true;
            this.rdBtn30.Text = "30%";
            this.rdBtn30.UseVisualStyleBackColor = true;
            this.rdBtn30.CheckedChanged += new System.EventHandler(this.rdBtn30_CheckedChanged);
            // 
            // rdBtn15
            // 
            this.rdBtn15.AutoSize = true;
            this.rdBtn15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBtn15.Location = new System.Drawing.Point(13, 10);
            this.rdBtn15.Name = "rdBtn15";
            this.rdBtn15.Size = new System.Drawing.Size(52, 20);
            this.rdBtn15.TabIndex = 14;
            this.rdBtn15.TabStop = true;
            this.rdBtn15.Text = "15%";
            this.rdBtn15.UseVisualStyleBackColor = true;
            this.rdBtn15.CheckedChanged += new System.EventHandler(this.rdBtn15_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(593, 378);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "Return:";
            // 
            // gpBxPayment
            // 
            this.gpBxPayment.Controls.Add(this.tbxCash);
            this.gpBxPayment.Controls.Add(this.rdBtnCredit);
            this.gpBxPayment.Controls.Add(this.rdBtnCash);
            this.gpBxPayment.Controls.Add(this.label14);
            this.gpBxPayment.Location = new System.Drawing.Point(578, 89);
            this.gpBxPayment.Name = "gpBxPayment";
            this.gpBxPayment.Size = new System.Drawing.Size(177, 99);
            this.gpBxPayment.TabIndex = 17;
            this.gpBxPayment.TabStop = false;
            // 
            // tbxCash
            // 
            this.tbxCash.Enabled = false;
            this.tbxCash.Location = new System.Drawing.Point(86, 64);
            this.tbxCash.Name = "tbxCash";
            this.tbxCash.Size = new System.Drawing.Size(78, 22);
            this.tbxCash.TabIndex = 15;
            // 
            // rdBtnCredit
            // 
            this.rdBtnCredit.AutoSize = true;
            this.rdBtnCredit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBtnCredit.Location = new System.Drawing.Point(6, 17);
            this.rdBtnCredit.Name = "rdBtnCredit";
            this.rdBtnCredit.Size = new System.Drawing.Size(93, 20);
            this.rdBtnCredit.TabIndex = 14;
            this.rdBtnCredit.TabStop = true;
            this.rdBtnCredit.Text = "Credit Card";
            this.rdBtnCredit.UseVisualStyleBackColor = true;
            // 
            // rdBtnCash
            // 
            this.rdBtnCash.AutoSize = true;
            this.rdBtnCash.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdBtnCash.Location = new System.Drawing.Point(100, 17);
            this.rdBtnCash.Name = "rdBtnCash";
            this.rdBtnCash.Size = new System.Drawing.Size(57, 20);
            this.rdBtnCash.TabIndex = 14;
            this.rdBtnCash.TabStop = true;
            this.rdBtnCash.Text = "Cash";
            this.rdBtnCash.UseVisualStyleBackColor = true;
            this.rdBtnCash.CheckedChanged += new System.EventHandler(this.rdBtnCash_CheckedChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Enabled = false;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(2, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 15);
            this.label14.TabIndex = 12;
            this.label14.Text = "Enter Cash:";
            // 
            // lblReturn
            // 
            this.lblReturn.BackColor = System.Drawing.Color.Transparent;
            this.lblReturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblReturn.Enabled = false;
            this.lblReturn.Location = new System.Drawing.Point(666, 377);
            this.lblReturn.Name = "lblReturn";
            this.lblReturn.Size = new System.Drawing.Size(85, 22);
            this.lblReturn.TabIndex = 13;
            // 
            // lblTotalToPay
            // 
            this.lblTotalToPay.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalToPay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalToPay.Location = new System.Drawing.Point(666, 343);
            this.lblTotalToPay.Name = "lblTotalToPay";
            this.lblTotalToPay.Size = new System.Drawing.Size(84, 23);
            this.lblTotalToPay.TabIndex = 13;
            // 
            // lblDiscount
            // 
            this.lblDiscount.BackColor = System.Drawing.Color.Transparent;
            this.lblDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDiscount.Location = new System.Drawing.Point(666, 306);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(84, 23);
            this.lblDiscount.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(561, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Total to Pay:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(580, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 15);
            this.label12.TabIndex = 12;
            this.label12.Text = "Discount:";
            // 
            // lblAmtTotal
            // 
            this.lblAmtTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblAmtTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAmtTotal.Location = new System.Drawing.Point(667, 229);
            this.lblAmtTotal.Name = "lblAmtTotal";
            this.lblAmtTotal.Size = new System.Drawing.Size(84, 23);
            this.lblAmtTotal.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(553, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 15);
            this.label10.TabIndex = 12;
            this.label10.Text = "Amount Total:";
            // 
            // lblTax
            // 
            this.lblTax.BackColor = System.Drawing.Color.Transparent;
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTax.Location = new System.Drawing.Point(667, 269);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(84, 23);
            this.lblTax.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(614, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "Tax:";
            // 
            // tbxQty
            // 
            this.tbxQty.Location = new System.Drawing.Point(411, 225);
            this.tbxQty.Name = "tbxQty";
            this.tbxQty.Size = new System.Drawing.Size(62, 22);
            this.tbxQty.TabIndex = 11;
            // 
            // lblPrice
            // 
            this.lblPrice.BackColor = System.Drawing.Color.Transparent;
            this.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrice.Location = new System.Drawing.Point(412, 191);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(62, 23);
            this.lblPrice.TabIndex = 10;
            // 
            // lblConsole
            // 
            this.lblConsole.BackColor = System.Drawing.Color.Transparent;
            this.lblConsole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConsole.Location = new System.Drawing.Point(412, 116);
            this.lblConsole.Name = "lblConsole";
            this.lblConsole.Size = new System.Drawing.Size(97, 23);
            this.lblConsole.TabIndex = 10;
            // 
            // lblQtyAv
            // 
            this.lblQtyAv.BackColor = System.Drawing.Color.Transparent;
            this.lblQtyAv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblQtyAv.Location = new System.Drawing.Point(412, 156);
            this.lblQtyAv.Name = "lblQtyAv";
            this.lblQtyAv.Size = new System.Drawing.Size(85, 23);
            this.lblQtyAv.TabIndex = 10;
            // 
            // lblProduct
            // 
            this.lblProduct.BackColor = System.Drawing.Color.Transparent;
            this.lblProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProduct.Location = new System.Drawing.Point(411, 79);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(121, 23);
            this.lblProduct.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(352, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Price:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(329, 228);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Quantity:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(331, 159);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "Qty Avail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(335, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Console:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(476, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Cashier Name";
            // 
            // labael2
            // 
            this.labael2.AutoSize = true;
            this.labael2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labael2.Location = new System.Drawing.Point(339, 80);
            this.labael2.Name = "labael2";
            this.labael2.Size = new System.Drawing.Size(60, 15);
            this.labael2.TabIndex = 6;
            this.labael2.Text = "Product:";
            // 
            // lblTime
            // 
            this.lblTime.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTime.Location = new System.Drawing.Point(361, 6);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(97, 19);
            this.lblTime.TabIndex = 4;
            // 
            // lblDate
            // 
            this.lblDate.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDate.Location = new System.Drawing.Point(257, 6);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(97, 19);
            this.lblDate.TabIndex = 4;
            // 
            // dataGridViewProduct
            // 
            this.dataGridViewProduct.BackgroundColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewProduct.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewProduct.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewProduct.Location = new System.Drawing.Point(11, 67);
            this.dataGridViewProduct.Name = "dataGridViewProduct";
            this.dataGridViewProduct.RowHeadersVisible = false;
            this.dataGridViewProduct.Size = new System.Drawing.Size(310, 184);
            this.dataGridViewProduct.TabIndex = 5;
            this.dataGridViewProduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProduct_CellClick);
            // 
            // lblClerkName
            // 
            this.lblClerkName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblClerkName.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblClerkName.Location = new System.Drawing.Point(578, 9);
            this.lblClerkName.Name = "lblClerkName";
            this.lblClerkName.Size = new System.Drawing.Size(131, 19);
            this.lblClerkName.TabIndex = 4;
            // 
            // dataGridViewList
            // 
            this.dataGridViewList.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewList.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewList.Location = new System.Drawing.Point(11, 302);
            this.dataGridViewList.Name = "dataGridViewList";
            this.dataGridViewList.RowHeadersVisible = false;
            this.dataGridViewList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewList.Size = new System.Drawing.Size(310, 131);
            this.dataGridViewList.TabIndex = 2;
            // 
            // btnLogout
            // 
            this.btnLogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogout.BackgroundImage")));
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(725, 4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(51, 27);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnCheckout
            // 
            this.btnCheckout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCheckout.BackgroundImage")));
            this.btnCheckout.Enabled = false;
            this.btnCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(654, 425);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(96, 27);
            this.btnCheckout.TabIndex = 1;
            this.btnCheckout.Text = "Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNewOrder.BackgroundImage")));
            this.btnNewOrder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewOrder.Location = new System.Drawing.Point(223, 35);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(97, 26);
            this.btnNewOrder.TabIndex = 1;
            this.btnNewOrder.Text = "Start Order";
            this.btnNewOrder.UseVisualStyleBackColor = true;
            this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clerk";
            // 
            // tabManager
            // 
            this.tabManager.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabManager.BackgroundImage")));
            this.tabManager.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabManager.Location = new System.Drawing.Point(4, 25);
            this.tabManager.Name = "tabManager";
            this.tabManager.Padding = new System.Windows.Forms.Padding(3);
            this.tabManager.Size = new System.Drawing.Size(781, 470);
            this.tabManager.TabIndex = 1;
            this.tabManager.Text = "Management";
            this.tabManager.UseVisualStyleBackColor = true;
            this.tabManager.Click += new System.EventHandler(this.tabManager_Click);
            // 
            // lblDbState
            // 
            this.lblDbState.BackColor = System.Drawing.Color.MidnightBlue;
            this.lblDbState.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDbState.Location = new System.Drawing.Point(12, 507);
            this.lblDbState.Name = "lblDbState";
            this.lblDbState.Size = new System.Drawing.Size(216, 23);
            this.lblDbState.TabIndex = 2;
            // 
            // buttonExit
            // 
            this.buttonExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExit.BackgroundImage")));
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.Color.White;
            this.buttonExit.Location = new System.Drawing.Point(411, 507);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "&Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(575, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 16);
            this.label13.TabIndex = 21;
            this.label13.Text = "Choose Payment:";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(824, 539);
            this.ControlBox = false;
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.lblDbState);
            this.Controls.Add(this.TabEmp);
            this.Name = "frmMain";
            this.Text = "Game Store Software";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.TabEmp.ResumeLayout(false);
            this.tabPOS.ResumeLayout(false);
            this.tabPOS.PerformLayout();
            this.gpBxDiscount.ResumeLayout(false);
            this.gpBxDiscount.PerformLayout();
            this.gpBxPayment.ResumeLayout(false);
            this.gpBxPayment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl TabEmp;
        private System.Windows.Forms.TabPage tabPOS;
        private System.Windows.Forms.TabPage tabManager;
        private System.Windows.Forms.Label lblClerkName;
        private System.Windows.Forms.DataGridView dataGridViewList;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Label lblDbState;
        private System.Windows.Forms.DataGridView dataGridViewProduct;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.TextBox tbxQty;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblConsole;
        private System.Windows.Forms.Label lblQtyAv;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labael2;
        private System.Windows.Forms.Button btnAddCart;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rdBtnCredit;
        private System.Windows.Forms.RadioButton rdBtnCash;
        private System.Windows.Forms.Label lblReturn;
        private System.Windows.Forms.Label lblTotalToPay;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblAmtTotal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.CheckBox cbxDiscount;
        private System.Windows.Forms.GroupBox gpBxDiscount;
        private System.Windows.Forms.RadioButton rdBtn50;
        private System.Windows.Forms.RadioButton rdBtn30;
        private System.Windows.Forms.RadioButton rdBtn15;
        private System.Windows.Forms.GroupBox gpBxPayment;
        private System.Windows.Forms.Label lblSelectProd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox tbxCash;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
    }
}