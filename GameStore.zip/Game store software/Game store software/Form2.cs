﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using ProductNamespace;//Class Product 




namespace Game_store_software
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();

            lblDate.Text = DateTime.Now.ToShortDateString();//Get date
            lblTime.Text = DateTime.Now.ToShortTimeString();//Get time
            dataGridViewList.Visible = false;
            dataGridViewProduct.Visible = false;
            label12.Enabled = false;
            label11.Enabled = false;
            btnAddCart.Enabled = false;
            

        }
        //Close App
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Class used to link and manage external data
        SqlConnection Connection = new SqlConnection("Server = cstnt.tstc.edu;" 
          + "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
         SqlCommand Cmd;
         SqlDataAdapter dataAd;
         DataTable dt;
         Product product;

        //Variable for calculation
        double totalPrice;
        int qtyReq;
        
        double tax = 0.0625;
        double AmountTotal = 0;
        double PriceTax = 0;
        double discount = 0;
        double cashreturned = 0;
        double cashReceived = 0;
        int qtyUpdate = 0;



        //Method to display table product
        public void showData()
        {
            try
            {
                Connection.Open();
                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataGridViewProduct.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        //Display DataGridViewProduct for cashier use only
        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            dataGridViewList.Visible = true;
            dataGridViewProduct.Visible = true;
            btnAddCart.Enabled = true;
            btnAddCart.Enabled = true;
            lblQtyAv.Enabled = true;
            lblSelectProd.Visible = true;
            showData();
            //Build datagriedviewCart to add up order in cart
            dataGridViewList.ColumnCount = 3;
            dataGridViewList.Columns[0].Name = "Product";
            dataGridViewList.Columns[1].Name = "Qty";
            dataGridViewList.Columns[2].Name = "Price";
        }

        //Method to pass value in DatagridViewList
        private void addCart(string Name, string Qty, string Price)
        {
            string[] row = { Name, Qty, Price };
            dataGridViewList.Rows.Add(row);
        }

        //Method for calculate  quantity total price
        private double QuantityPrice(double priceProduct, int qtyProd)
        {
            double Total;
            Total = priceProduct * qtyProd;
            return Total;
        }

        //Add selected product in the datagridViewList
        private void btnAddCart_Click(object sender, EventArgs e)
        {
           
            double totalList = 0;
            dataGridViewList.ClearSelection();//Disable auto select in datagridview
            btnCheckout.Enabled = true;
            cbxDiscount.Enabled = true;
            try
            {
                if (tbxQty.Text != "" && lblQtyAv.Text != "" && lblPrice.Text != "")//Make sure to enter input
                {
                    //ACCEPT INPUT FROM USER 
                    qtyReq = int.Parse(tbxQty.Text);

                    if (qtyReq > 0 && qtyReq < int.MaxValue)//range of number accepted 
                    {
                        //Check if quantity is available
                        if (qtyReq < product.Quantity)
                        {
                            //Display selection in the cart and increment total                   
                            totalPrice = QuantityPrice(product.Price, qtyReq);
                            string strtotalPrice = totalPrice.ToString();
                            addCart(product.Name, tbxQty.Text, strtotalPrice);

                            //substract qty available to qty req to update qty in the dataGridProduct                  
                            qtyUpdate = product.Quantity - qtyReq;
                            //grab current row index selected          
                            int x = dataGridViewProduct.CurrentCell.RowIndex;
                            //Insert quantity updated to current row and Cell "Quantity" index 2
                            dataGridViewProduct.Rows[x].Cells[2].Value = Convert.ToString(qtyUpdate);
                        }
                        else//if quantity out of stock
                        {
                            MessageBox.Show("Quantity Unavailable", "Message");
                            tbxQty.Focus();
                            tbxQty.Clear();
                        }

                    }
                    else //if quantity negatif number
                    {
                        MessageBox.Show(" Invalid quantity number", "Message");
                        tbxQty.Focus();
                        tbxQty.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("Please, Select Product or Enter Quantity ", "Message");
                    tbxQty.Focus();
                    tbxQty.Clear();

                }


                lblQtyAv.Text = "";
                lblProduct.Text = "";
                lblConsole.Text = "";
                tbxQty.Text = "";
                lblPrice.Text = "";


                if (dataGridViewList.Rows.Count > 1)//make sure datalist is not empty
                {

                    //cumulate Total Price of order in the cart
                    for (int i = 0; i < dataGridViewList.Rows.Count - 1; i++)
                    {
                        totalList = totalList + Convert.ToDouble(dataGridViewList.Rows[i].Cells[2].Value.ToString());
                    }

                    PriceTax = totalList * tax;
                    AmountTotal = totalList + PriceTax;
                    lblAmtTotal.Text = totalList.ToString("N2");
                    lblTotalToPay.Text = AmountTotal.ToString("N2");
                    lblTax.Text = PriceTax.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Please Add Product in the cart", "Message");
                    gpBxPayment.Focus();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show(" Numeric Input ", "Message");
                tbxQty.Text = "";
                tbxQty.Focus();
                lblConsole.Text = "";
                lblProduct.Text = "";
                lblQtyAv.Text = "";
                lblPrice.Text = "";
            }

            

        }
   
        //Display grid selection in the labels
        private void dataGridViewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tbxQty.Focus();

            try
            {
                
                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.dataGridViewProduct.Rows[e.RowIndex];                   
                    product = new Product();
                    product.Name = row.Cells["Description"].Value.ToString();
                    product.Quantity = int.Parse(row.Cells["Quantity"].Value.ToString());
                    product.Price = Convert.ToDouble(row.Cells["Retail"].Value.ToString());                   
                    product.Category = row.Cells["Category"].Value.ToString();
                    product.Console = row.Cells["Console"].Value.ToString();
                    

                    lblQtyAv.Text = Convert.ToString(product.Quantity);
                    lblPrice.Text = Convert.ToString(product.Price);
                    lblProduct.Text= Convert.ToString(product.Name);
                    lblConsole.Text = Convert.ToString(product.Console);
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }

        }

        public string EmployeeType;
        private void Form2_Load(object sender, EventArgs e)
        {
            if (EmployeeType == "Employee")
            {

            }
        }


        //CHECKOUT
        private void btnCheckout_Click(object sender, EventArgs e)
        {


            if (rdBtnCash.Checked == true || rdBtnCredit.Checked == true)//make sure to choose payment method

            {
                //if Cash checked
                if (rdBtnCash.Checked == true)//display cash received and returned                                 
                {
                    label11.Enabled = true;
                    label14.Enabled = true;
                    tbxCash.Enabled = true;
                    tbxCash.Focus();
                    lblReturn.Enabled = true;

                    if (tbxCash.Text != "")//make sure to enter cash
                    {
                        cashReceived = double.Parse(tbxCash.Text);

                        cashreturned = cashReceived - AmountTotal;
                        lblReturn.Text = cashreturned.ToString("N2");

                        lblTotalToPay.Text = AmountTotal.ToString("N2");
                        lblDiscount.Text = discount.ToString("N2");
                        lblTax.Text = PriceTax.ToString("N2");

                        //Message and Action when transaction made
                        DialogResult result = MessageBox.Show("Do you want to start New Order", "Succesfull Transaction", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            reset();
                        }
                        else
                        {
                            tbxQty.Enabled = false;
                            tbxCash.Enabled = false;
                            dataGridViewProduct.Enabled= false;
                            btnAddCart.Enabled = false;
                            btnNewOrder.Enabled = false;
                            btnCheckout.Enabled = false;
                        }
                      
                    }
                    else
                    {
                        MessageBox.Show("Enter your cash", "Message");
                        tbxCash.Focus();
                        cashReceived = 0;
                    }

                }
                else//if credit card checked
                {
                    MessageBox.Show("Please Insert card", "Credit Card");

                    //Message and Action when transaction made
                    DialogResult result = MessageBox.Show("Do you want to start New Order", "Succesfull Transaction", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        reset();
                    }
                    else
                    {
                        tbxQty.Enabled = false;
                        tbxCash.Enabled = false;
                        dataGridViewProduct.Enabled = false;
                        btnAddCart.Enabled = false;
                    }

                }
            }
            else
            {
                MessageBox.Show("Please choose payment method", "Payment Method");
            }
            
        }


        //Activate discount
        private void cbxDiscount_CheckedChanged(object sender, EventArgs e)
        {
            
            if(cbxDiscount.Checked==false)
            {
                gpBxDiscount.Enabled = false;

                reset();
            }
            else
            {
                gpBxDiscount.Enabled = true;
                label12.Enabled = true;
            }
            
        }

        private void rdBtn15_CheckedChanged(object sender, EventArgs e)
        {
            discount = AmountTotal * 0.15;
            AmountTotal = AmountTotal - discount;
            lblTotalToPay.Text = AmountTotal.ToString("N2");
            lblDiscount.Text = discount.ToString("N2");
            rdBtn30.Enabled = false;
            rdBtn50.Enabled = false;

        }

        private void rdBtn30_CheckedChanged(object sender, EventArgs e)
        {
            discount = AmountTotal * 0.30;
            AmountTotal = AmountTotal - discount;
            lblTotalToPay.Text = AmountTotal.ToString("N2");
            lblDiscount.Text = discount.ToString("N2");
            rdBtn15.Enabled = false;
            rdBtn50.Enabled = false;
        }

        private void rdBtn50_CheckedChanged(object sender, EventArgs e)
        {
            discount = AmountTotal * 0.50;
            AmountTotal = AmountTotal - discount;
            lblTotalToPay.Text = AmountTotal.ToString("N2");
            lblDiscount.Text = discount.ToString("N2");
            rdBtn15.Enabled = false;
            rdBtn30.Enabled = false;
        }
        private void rdBtnCash_CheckedChanged(object sender, EventArgs e)
        {
            label11.Enabled = true;
            label14.Enabled = true;
            tbxCash.Enabled = true;
            tbxCash.Focus();
            lblReturn.Enabled = true;            
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        public void reset()//Method for reset
        {
            //reset if start new order
            dataGridViewList.Rows.Clear();
            AmountTotal = 0;
            PriceTax = 0;
            discount = 0;
            cashreturned = 0;
            cashReceived = 0;
            totalPrice = 0;
            lblAmtTotal.Text = "";
            lblDiscount.Text = "";
            lblReturn.Text = "";
            lblTax.Text = "";
            tbxCash.Text = "";
            lblTotalToPay.Text = "";
            dataGridViewList.Visible = false;
            dataGridViewProduct.Visible = false;
            rdBtnCash.Checked = false;
            rdBtnCredit.Checked = false;
            tbxCash.Enabled = false;
            lblReturn.Enabled = false;
            cbxDiscount.Enabled = false;
            cbxDiscount.Checked = false;
            btnAddCart.Enabled = false;
            lblQtyAv.Enabled = false;
        }

        //Logout
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            reset();
        }

        private void tabEmployee_Click(object sender, EventArgs e)
        {

        }

        private void tabManager_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {

        }

      
    }
}
