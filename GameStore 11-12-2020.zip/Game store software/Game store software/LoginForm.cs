﻿using LoginValidationNamespace;
using System;
using System.Data.SqlClient;//Database connection
using System.Windows.Forms;

namespace Game_store_software
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        //database sqlconnection object declaration
        private SqlConnection cntDatabase;

        private LoginValidation attempt;

        private void Form1_Load(object sender, EventArgs e)
        {
            // btnLog.Enabled = false;

            //connect to database
            cntDatabase = new SqlConnection("Server=cstnt.tstc.edu;" +
                "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
            //open the database
            cntDatabase.Open();
            //display message
            lblMessage.Text = cntDatabase.State.ToString();
            //close the database
            cntDatabase.Close();
            lblMessage.Text += cntDatabase.State.ToString();
            //dispose of the connection object
            cntDatabase.Dispose();
        }

        private void LoginClick(object sender, EventArgs e)
        {
            //in this click event, the user inputs in the text boxes will be sent into an object where thsoe passwords and
            //username will be validated prior to allowing the user to go forward

            string user = txtUsername.Text;
            string pass = txtPassword.Text;
            bool approval = false;

            
            //declaration and instantiation of a class
            attempt = new LoginValidation(user, pass, approval);

            //calls class properties to assign values to the private fields
            attempt.Username = txtUsername.Text;
            attempt.Password = txtPassword.Text;

            FormTransition(attempt.YayOrNay);
        }

        private void FormTransition(bool pVal) 
        {
        if (pVal == true)
            {
                frmCashier frm2 = new frmCashier(); //creates new form obejct 
                frm2.Show(); // shows the object instantiation of the from object created

                this.Hide(); // hides the loggin form
            }
            else
            {
                //resets text boxes
                txtPassword.Text = "";
                txtUsername.Text = "";
                txtUsername.Focus();
            }
        }
        

    }
}