﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using ProductNamespace;//Class Product 
using LoginValidationNamespace; //login validation 




namespace Game_store_software
{
    public partial class frmCashier : Form
    {
        public frmCashier()
        {
            InitializeComponent();

            lblDate.Text = DateTime.Now.ToShortDateString();//Get date
            lblTime.Text = DateTime.Now.ToShortTimeString();//Get time

        }
        //Close App
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Class used to link and manage external data
        SqlConnection Connection = new SqlConnection("Server = cstnt.tstc.edu;" 
          + "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");
         SqlCommand Cmd;
         SqlDataAdapter dataAd;
         DataTable dt;
         Product product;

        //Variable for calculation
        double totalPrice;
        int qtyReq;
        double totalList = 0;
        double tax = 0.0625;
        double AmountTotal = 0;
        double PriceTax = 0;
        double discount = 0;
        double cashreturned = 0;
        double cashReceived = 0;



        //Method to display table product
        public void showData()
        {
            try
            {
                Connection.Open();
                dataAd = new SqlDataAdapter("SELECT Description,Console,Quantity,Category,Retail  FROM group3fa202330.Products", Connection);
                dt = new DataTable();
                dataAd.Fill(dt);
                dataGridViewProduct.DataSource = dt;
                Connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        //Display DataGridViewProduct for cashier use only
        private void btnNewOrder_Click(object sender, EventArgs e)
        {
           
           dataGridViewProduct.ClearSelection(); //Disable auto select in datagridview

            btnAddCart.Enabled = true;
            lblSelectProd.Visible = true;
            showData();
            //Build datagriedviewCart to add up order in cart
            dataGridViewList.ColumnCount = 3;
            dataGridViewList.Columns[0].Name = "Product";
            dataGridViewList.Columns[1].Name = "Qty";
            dataGridViewList.Columns[2].Name = "Price";
        }

        //Method to pass value in DatagridViewList
        private void addCart(string Name, string Qty, string Price)
        {
            string[] row = { Name, Qty, Price };
            dataGridViewList.Rows.Add(row);
        }

        //Method for calculate  quantity total price
        private double QuantityPrice(double priceProduct, int qtyProd)
        {
            double Total;
            Total = priceProduct * qtyProd;
            return Total;
        }

        //Add selected product in the datagridViewList
        private void btnAddCart_Click(object sender, EventArgs e)
        {
            
            dataGridViewList.ClearSelection();//Disable auto select in datagridview
            btnCheckout.Enabled = true;

            if (tbxQty.Text != "" && lblQtyAv.Text != "" && lblPrice.Text != "")//Make sure to enter input
            {
                //ACCEPT INPUT FROM USER 
                qtyReq = int.Parse(tbxQty.Text);

                if (qtyReq > 0 && qtyReq < int.MaxValue)//range of number accepted 
                {
                    //Check if quantity is available
                    if (qtyReq < product.Quantity)
                    {
                        //Display selection in the cart and increment total                   
                        totalPrice = QuantityPrice(product.Price, qtyReq);
                        string strtotalPrice = totalPrice.ToString();
                        addCart(product.Name, tbxQty.Text, strtotalPrice);
                    }
                    else//if quantity out of stock
                    {
                        MessageBox.Show("Quantity Unavailable", "Message");
                        tbxQty.Focus();
                        tbxQty.Clear();
                    }

                }
                else //if quantity negatif number
                {
                    MessageBox.Show(" Invalid quantity number", "Message");
                    tbxQty.Focus();
                    tbxQty.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please, Select Product or Enter Quantity ", "Message");
                tbxQty.Focus();
                tbxQty.Clear();

            }
        
               
            lblQtyAv.Text = "";
            lblProduct.Text = "";
            lblConsole.Text = "";
            tbxQty.Text = "";
            lblPrice.Text = "";
            tbxQty.Focus();
        }

        //Display grid selection in the labels
        private void dataGridViewProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tbxQty.Focus();

            try
            {
                
                if (e.RowIndex >= 0)
                {
                    //instantiate object from product class and assign value from cell
                    DataGridViewRow row = this.dataGridViewProduct.Rows[e.RowIndex];                   
                    product = new Product();
                    product.Name = row.Cells["Description"].Value.ToString();
                    product.Quantity = int.Parse(row.Cells["Quantity"].Value.ToString());
                    product.Price = Convert.ToDouble(row.Cells["Retail"].Value.ToString());                   
                    product.Category = row.Cells["Category"].Value.ToString();
                    product.Console = row.Cells["Console"].Value.ToString();
                    

                    lblQtyAv.Text = Convert.ToString(product.Quantity);
                    lblPrice.Text = Convert.ToString(product.Price);
                    lblProduct.Text= Convert.ToString(product.Name);
                    lblConsole.Text = Convert.ToString(product.Console);
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }

        }

        public string EmployeeType;
        private void Form2_Load(object sender, EventArgs e)
        {
            if (EmployeeType == "Employee")
            {

            }
        }


        //CHECKOUT
        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (rdBtnCash.Checked == true || rdBtnCredit.Checked == true)//make sure to choose payment method
                
            {
               
                if (dataGridViewList.Rows.Count > 1)//make sure datalist is not empty
                {
                    
                    //cumulate Total Price of order in the cart
                    for (int i = 0; i < dataGridViewList.Rows.Count - 1; i++)
                        {

                            totalList = totalList + Convert.ToDouble(dataGridViewList.Rows[i].Cells[2].Value.ToString());
                           
                        }
                        //calcul and display amount including tax and discount
                        

                        if (rdBtn15.Checked == true)
                        {
                            discount = totalList * 0.15;
                        }
                        else if (rdBtn30.Checked == true)
                        {
                            discount = totalList * 0.30;
                        }
                        else if (rdBtn50.Checked == true)
                        {
                            discount = totalList * 0.50;
                        }

                    //if Cash checked
                    if (rdBtnCash.Checked == true)//display cash received and returned
                    {
                        label11.Enabled = true;
                        label14.Enabled = true;
                        tbxCash.Enabled = true;
                        lblReturn.Enabled = true;

                        if (tbxCash.Text !="")//make sure to enter cash
                        {
                            cashReceived = double.Parse(tbxCash.Text);
                            PriceTax = (totalList - discount) * tax;                           
                            AmountTotal = totalList + PriceTax;                                                     
                            cashreturned = cashReceived- AmountTotal;
                            lblReturn.Text = cashreturned.ToString("N2");
                            lblAmtTotal.Text = totalList.ToString("N2");
                            lblTotalToPay.Text = AmountTotal.ToString("N2");
                            lblDiscount.Text = discount.ToString("N2");
                            lblTax.Text = PriceTax.ToString("N2");
                        }
                        else
                        {
                            MessageBox.Show("Enter your cash","Message");
                            tbxCash.Focus();
                            totalList = 0;
                            cashReceived = 0;
                            lblAmtTotal.Text = "";
                        }

                       
                    }
                    else//if credit card checked
                    {
                        PriceTax = (totalList - discount) * tax;
                        lblTax.Text = PriceTax.ToString("N2");
                        AmountTotal = totalList + PriceTax;
                        lblAmtTotal.Text = totalList.ToString("N2");
                        lblTotalToPay.Text = AmountTotal.ToString("N2");
                        lblDiscount.Text = discount.ToString();
                    }


                }
                else
                {
                    MessageBox.Show("Please Add Product in the cart", "Message");
                    gpBxPayment.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please choose payment method", "Payment Method");
            }
        }
        //Activate discount
        private void cbxDiscount_CheckedChanged(object sender, EventArgs e)
        {
            if(cbxDiscount.Checked==false)
            {
                gpBxDiscount.Enabled = false;
            }
            else
            {
                gpBxDiscount.Enabled = true;
            }
            
        }

        private void tabEmployee_Click(object sender, EventArgs e)
        {
            
        }

        private void tabManager_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void lblPrice_Click(object sender, EventArgs e)
        {

        }

       
    }
}
