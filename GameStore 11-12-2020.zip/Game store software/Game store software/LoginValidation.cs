﻿using System.Data.SqlClient;//Database connection
using System.Windows.Forms;

namespace LoginValidationNamespace
{
    public class LoginValidation
    {
        private SqlConnection connection; //connection object
        private SqlCommand command; //command object
        private SqlDataReader reader; //datareader object

        //attributes
        private string username;

        private string password;
        private bool yayOrNay;

        //constructors
        public LoginValidation()
        {
            username = "";
            password = "";
        }

        //this constructor receives two values and passed
        public LoginValidation(string pUser, string pPW, bool pBool)
        {
            username = pUser;
            password = pPW;
            yayOrNay = pBool;

            //connect to the database
            connection = new SqlConnection("Server=cstnt.tstc.edu;" + "Database= INEW2330fa20 ;User Id=group3fa202330; password = 1954195");

            //opens the connection
            connection.Open();

            //passes connection to a command object
            command = new SqlCommand("SELECT Username, Password FROM group3fa202330.Employees;", connection);

            //gets the results from the sql command
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                //iterates through the username column to find a matching value
                //after it finds a matching user name it then moves to the password column for that row.
                if (reader["Username"].ToString() == pUser) //compares curent username on the current row
                {
                    if (reader["Password"].ToString() == pPW) //compares the password of the current row
                    {
                        yayOrNay = true;
                    }
                }
            }

            //tells user if they are good to go
            if (yayOrNay == false)
            {
                MessageBox.Show("Login Failed");
            }

            if (reader != null)
            {
                reader.Close(); //closes the reader
            }
            if (connection != null)
            {
                connection.Close(); //closes connection to database
            }

            //dispose of the connection object
            connection.Dispose();
        }

        //properties
        public string Username
        {
            set { username = value; }

            get { return username; }
        }

        public string Password
        {
            set { password = value; }

            get { return password; }
        }

        public bool YayOrNay
        {
            set { yayOrNay = value; }

            get { return yayOrNay; }
        }
    }
}